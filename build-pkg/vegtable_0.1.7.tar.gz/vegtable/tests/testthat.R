## browseURL(paste0("https://walczak.org/2017/06/",
##                 "how-to-add-code-coverage-codecov-to-your-r-package/"))

library(testthat)
library(vegtable)

test_check("vegtable")
